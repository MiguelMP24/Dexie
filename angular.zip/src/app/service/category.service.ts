import { Injectable } from '@angular/core';
import { Category } from '../models/category';
import { v4 as uuidv4 } from 'uuid';
import { OnlineOfflineService } from './online-offline.service';
import Dexie from 'dexie';
import { async } from '@angular/core/testing';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  private Data: Category[] = [];
  private db: any;

  addData(data: Category) {
    data.id = uuidv4();
    this.Data.push(data)
    if (this.OnlineOfflineService.isOnline) {
      this.addToIndexDB(data);
    }
  }

  getData() {
    return this.Data;
  }

  constructor(private readonly OnlineOfflineService: OnlineOfflineService) {
    this.registerToEvents(OnlineOfflineService);
    this.createDatabase();
  }

  private createDatabase() {
    this.db = new Dexie('MyDatabase');
    this.db.version(1).stores({
      category: 'id, name'
    });
  }

  private addToIndexDB(Data: Category) {
    this.db.category.add(Data).then(async () => {
      const allItems: Category[] = await this.db.category.toArray();
      console.log(allItems);

    }).catch((e: any) => {
      console.log(e);
    })
  }

  private registerToEvents(OnlineOfflineService: OnlineOfflineService) {
    OnlineOfflineService.connectionChanged.subscribe(online => {
      if (online) {
        console.log('Send Data');
        this.sendItemsFromIndexDB();
      } else {
        console.log('Save Data Locale');
      }
    })
  }

  private async sendItemsFromIndexDB() {
    const allItems: Category[] = await this.db.category.toArray();
    allItems.forEach((item: Category) => {
      this.db.category.delete(item.id).then(() => {
        console.log(`Item: $(item.id)`);
      }
      );
    });
  }

}