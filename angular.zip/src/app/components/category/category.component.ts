import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Category } from 'src/app/models/category';
import { CategoryService } from 'src/app/service/category.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.scss']
})
export class CategoryComponent {
  Data: Category[] = [];
  Formulario: FormGroup = new FormGroup({
    name: new FormControl('', Validators.required)
});

constructor(private readonly CategoryService:CategoryService){
  this.Data = this.CategoryService.getData();
}

  addSave(){
    this.CategoryService.addData(this.Formulario.value);
    this.Formulario.reset();
  }
}
